"""Reproducible real-model smoke checks, plus diagnostic observations."""
from inference import Classifier, ROOT
import io, json
from PIL import Image

def verify():
    c = Classifier()
    cases = [('tomato-early-blight','Tomato'),('potato-late-blight','Potato'),
             ('apple-scab-heavy','Apple'),('corn-rust','Corn'),('grape-black-rot','Grape'),
             ('healthy-tomato','Tomato'),('blurry-leaf','Tomato'),
             ('benchmark-apple_apple_scab','Apple'),('benchmark-grape_black_rot','Grape')]
    results = []
    for name, crop in cases:
        result = c.predict((ROOT/'public'/'samples'/(name+'.jpg')).read_bytes(), crop)
        assert 0 <= result['confidence'] <= 1
        assert result['severity'] is None
        assert len(result['candidates']) == 5
        if name == 'blurry-leaf':
            assert not result['accepted'] and any('blurry' in x for x in result['reasons'])
        if name.startswith('benchmark-'):
            assert result['accepted'], (name, result)
        results.append({'file':name+'.jpg','selected_crop':crop,**result})
        print(name, 'PASS GATE' if result['accepted'] else 'HOLD', result['label'])
    solid=io.BytesIO();Image.new('RGB',(256,256),'green').save(solid,format='PNG')
    assert not c.predict(solid.getvalue(),'Tomato')['accepted']
    mismatch=c.predict((ROOT/'public/samples/benchmark-apple_apple_scab.jpg').read_bytes(),'Tomato')
    assert not mismatch['accepted'] and any('different crop' in x for x in mismatch['reasons'])
    (ROOT/'evaluation.json').write_text(json.dumps(results,indent=2),encoding='utf-8')
    print('Smoke checks passed. Observations saved to app/evaluation.json; these are not a field accuracy study.')

if __name__=='__main__': verify()
