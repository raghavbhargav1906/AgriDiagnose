"""Integration checks against the running local service."""
import base64, json, urllib.request, urllib.error
from pathlib import Path
ROOT=Path(__file__).resolve().parent
BASE='http://127.0.0.1:8765'

def request(path, payload=None, origin=None):
    data=None if payload is None else json.dumps(payload).encode()
    headers={'Content-Type':'application/json'}
    if origin:headers['Origin']=origin
    req=urllib.request.Request(BASE+path,data=data,headers=headers)
    try:
        with urllib.request.urlopen(req,timeout=15) as response:
            return response.status,json.load(response)
    except urllib.error.HTTPError as error:
        return error.code,json.load(error)

assert request('/api/health')[1]['ready']
image=base64.b64encode((ROOT/'public/samples/benchmark-apple_apple_scab.jpg').read_bytes()).decode()
payload={'image':image,'crop':'Apple','gate':.65}
code,result=request('/api/diagnose',payload)
assert code==200 and result['accepted'] and result['label']=='Apple___Apple_scab'
assert request('/api/diagnose',{**payload,'image':'not base64!'})[0]==400
assert request('/api/diagnose',{**payload,'gate':2})[0]==400
assert request('/api/diagnose',{**payload,'crop':'Unknown'})[0]==400
assert request('/api/diagnose',payload,'https://example.com')[0]==403
assert request('/api/unknown',payload)[0]==404
print('HTTP integration checks passed: real inference, malformed image, invalid gate/crop, cross-origin rejection and unknown endpoint.')
