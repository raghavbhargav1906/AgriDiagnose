"""Download pinned, public model artifacts. No remote Python code is executed."""
from pathlib import Path
import hashlib, json, urllib.request
ROOT=Path(__file__).resolve().parent
manifest=json.loads((ROOT/'models/manifest.json').read_text())
for artifact in manifest['artifacts']:
    target=ROOT/artifact['path']
    if target.exists() and hashlib.sha256(target.read_bytes()).hexdigest()==artifact['sha256']:
        print('Verified:',target.name);continue
    target.parent.mkdir(parents=True,exist_ok=True)
    temporary=target.with_suffix(target.suffix+'.download')
    print('Downloading:',target.name)
    urllib.request.urlretrieve(artifact['url'],temporary)
    if hashlib.sha256(temporary.read_bytes()).hexdigest()!=artifact['sha256']:
        raise ValueError('Hash mismatch: '+target.name)
    temporary.replace(target)
print('Model ready. Inference works without network access.')
