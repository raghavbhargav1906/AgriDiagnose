"""CPU inference. Images never leave this process."""
import sys
from pathlib import Path
ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'vendor'))
import io, json, time
import numpy as np
from PIL import Image, ImageOps
import onnxruntime as ort

MODEL = ROOT / 'models'
META = json.loads((MODEL / 'meta.json').read_text())
LABELS = META['labels']
Image.MAX_IMAGE_PIXELS = 25_000_000

class Classifier:
    def __init__(self):
        options = ort.SessionOptions()
        options.intra_op_num_threads = 2
        self.session = ort.InferenceSession(str(MODEL / 'classifier.onnx'), options,
                                           providers=['CPUExecutionProvider'])
        self.centroids = np.fromfile(MODEL / 'centroids.f32', dtype='<f4').reshape(len(LABELS), -1)
        self.labels = LABELS
        self.threshold = META['threshold']
        self.head = None
        custom = MODEL / 'local-head.npz'
        if custom.exists():
            self.head = np.load(custom, allow_pickle=False)
            self.labels = self.head['labels'].tolist()
            self.centroids = self.head['centroids']
            self.threshold = float(self.head['threshold'])

    def extract(self, raw):
        with Image.open(io.BytesIO(raw)) as src:
            if src.format not in ('JPEG', 'PNG', 'WEBP'):
                raise ValueError('Use a JPEG, PNG or WebP image.')
            image = ImageOps.exif_transpose(src).convert('RGB')
            width, height = image.size
            if min(width, height) < 64:
                raise ValueError('Image is too small. Use at least 64 pixels on each side.')
            scale = 256 / min(width, height)
            image = image.resize((int(width * scale), int(height * scale)), Image.Resampling.BICUBIC)
            left, top = (image.width - 224) // 2, (image.height - 224) // 2
            image = image.crop((left, top, left + 224, top + 224))
        pixels = np.asarray(image, dtype=np.float32) / 255
        grey = pixels.mean(axis=2) * 255
        lap = -4 * grey[1:-1, 1:-1] + grey[:-2, 1:-1] + grey[2:, 1:-1] + grey[1:-1, :-2] + grey[1:-1, 2:]
        sharpness = float(lap.var())
        tensor = ((pixels - np.array([.485, .456, .406], dtype=np.float32)) /
                  np.array([.229, .224, .225], dtype=np.float32)).transpose(2, 0, 1)[None]
        outputs = self.session.run(['logits', 'features'], {'pixel_values': tensor})
        return outputs[0][0], outputs[1][0], sharpness, [width, height]

    def predict(self, raw, crop, gate=.65):
        start = time.perf_counter()
        logits, features, sharpness, size = self.extract(raw)
        if self.head is not None:
            x = (features - self.head['mean']) / self.head['scale']
            logits = (x @ self.head['weights'] + self.head['bias']) / float(self.head['temperature'])
        p = np.exp(logits - logits.max()); p /= p.sum()
        best = int(p.argmax())
        norm = features / max(float(np.linalg.norm(features)), 1e-12)
        similarity = float((self.centroids @ norm).max())
        label = self.labels[best]
        detected_crop, disease = label.split('___', 1)
        reasons = []
        if sharpness < 35:
            reasons.append('The photo is blurry. Retake a close, focused photo of one leaf.')
        if similarity < self.threshold:
            reasons.append('The photo differs from the model training examples. Try one leaf against a plain background.')
        if not detected_crop.lower().startswith(crop.lower()):
            reasons.append('The model detected a different crop. Check the crop selection and photograph.')
        if float(p[best]) < gate:
            reasons.append('The top model score is below your confidence gate. Retake the photo or ask an expert.')
        return dict(label=label, disease=disease.replace('_', ' ').strip(),
                    crop=detected_crop, confidence=float(p[best]), accepted=not reasons,
                    reasons=reasons, sharpness=round(sharpness, 2), similarity=round(similarity, 4),
                    similarity_threshold=self.threshold, gate=gate, size=size,
                    model='Locally trained DINOv2 head' if self.head is not None else 'PlantVillage DINOv2-small (INT8)',
                    severity=None, severity_source='Not trained; enter a visual estimate separately',
                    candidates=[dict(label=self.labels[int(i)], probability=float(p[i])) for i in np.argsort(p)[-5:][::-1]],
                    elapsed_ms=round((time.perf_counter()-start)*1000))
