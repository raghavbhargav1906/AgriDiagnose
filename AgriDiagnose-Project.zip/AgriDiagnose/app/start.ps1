$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath $PSScriptRoot
$bundledPython = Join-Path $env:USERPROFILE '.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe'
$venvPython = Join-Path $PSScriptRoot '.venv\Scripts\python.exe'
if (Test-Path -LiteralPath $venvPython) { $appPython = $venvPython }
elseif (Test-Path -LiteralPath $bundledPython) { $appPython = $bundledPython }
elseif (Get-Command py -ErrorAction SilentlyContinue) { $appPython = 'py' }
else { throw 'Python 3.12+ is required. See README.md for setup.' }
try {
    $health = Invoke-RestMethod 'http://127.0.0.1:8765/api/health' -TimeoutSec 2
    if ($health.ready -and $health.local) {
        Start-Process 'http://127.0.0.1:8765'
        Write-Host 'AgriDiagnose is already running.'
        exit 0
    }
} catch { }
Write-Host 'Starting AgriDiagnose. Keep this window open. Press Ctrl+C to stop.'
Write-Host 'Open http://127.0.0.1:8765 in your browser once the ready message appears.'
& $appPython server.py --open
exit $LASTEXITCODE
