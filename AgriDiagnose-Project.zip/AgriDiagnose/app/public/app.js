'use strict';
const $ = id => document.getElementById(id);
const esc = value => String(value).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const samples = [
 ['tomato-early-blight','Tomato early blight','Tomato'],['potato-late-blight','Potato late blight','Potato'],
 ['apple-scab-heavy','Apple scab, heavy','Apple'],['corn-rust','Corn rust','Corn'],
 ['grape-black-rot','Grape black rot','Grape'],['healthy-tomato','Healthy tomato','Tomato'],['blurry-leaf','Blurry photo','Tomato']
];
let photo=null, filename='', result=null, revision=0, busy=false, ready=false, severity=null;
let history=[];
try {history=JSON.parse(localStorage.getItem('agridiagnose.scans')||'[]'); if(!Array.isArray(history)) history=[];} catch {history=[];}
const pct = n => (n*100).toFixed(1)+'%';
function error(message){$('result').innerHTML=`<div class="error"><h3>Let’s try that again</h3><p>${esc(message)}</p></div>`;}
function reset(){revision++;result=null;severity=null;$('status').textContent='PHOTO READY';$('result').innerHTML='<div class="empty"><h3>Ready for a closer look.</h3><p>Select your crop, then analyse the leaf.</p></div>';}
function controls(){ $('analyse').disabled=!photo||busy||!ready; $('analyse').textContent=busy?'Analysing locally…':'Analyse leaf →'; }
async function loadPhoto(blob,name){
 if(!['image/jpeg','image/png','image/webp'].includes(blob.type)||blob.size>8*1024*1024){error('Choose a JPG, PNG or WebP under 8 MB.');return;}
 const token=++revision;
 const data=await new Promise((resolve,reject)=>{const r=new FileReader();r.onload=()=>resolve(r.result);r.onerror=reject;r.readAsDataURL(blob);});
 if(token!==revision)return;
 const image=new Image();image.src=data;
 try {await image.decode();} catch {error('This file could not be read as an image.');return;}
 if(token!==revision)return;
 photo=data;filename=name;reset();$('preview').src=data;$('preview').hidden=false;$('uploadIntro').hidden=true;$('fileNote').textContent=name;controls();
}
const benchmarks=[['benchmark-apple_apple_scab','Reference: Apple scab','Apple'],['benchmark-grape_black_rot','Reference: Grape black rot','Grape']];
function sampleButtons(list){return list.map(([id,name])=>`<button class="sample" type="button" data-id="${id}" title="${name}" aria-label="Load ${name}"><img src="samples/${id}.jpg" alt="${name}"></button>`).join('');}
$('samples').innerHTML=sampleButtons(samples);$('benchmarkSamples').innerHTML=sampleButtons(benchmarks);
async function selectSample(e){const b=e.target.closest('button');if(!b||busy)return;try{const [id,name,crop]=[...samples,...benchmarks].find(s=>s[0]===b.dataset.id);const response=await fetch(`samples/${id}.jpg`);if(!response.ok)throw Error('Could not load example.');$('crop').value=crop;await loadPhoto(await response.blob(),name);document.querySelectorAll('.sample').forEach(el=>el.classList.toggle('selected',el===b));}catch(e){error(e.message);}}
$('samples').onclick=selectSample;$('benchmarkSamples').onclick=selectSample;
$('file').onchange=e=>{if(e.target.files[0]){document.querySelectorAll('.sample').forEach(el=>el.classList.remove('selected'));loadPhoto(e.target.files[0],e.target.files[0].name).catch(()=>error('Could not read file.'));}e.target.value='';};
for(const event of ['dragenter','dragover'])$('dropzone').addEventListener(event,e=>{e.preventDefault();$('dropzone').classList.add('drag');});
for(const event of ['dragleave','drop'])$('dropzone').addEventListener(event,e=>{e.preventDefault();$('dropzone').classList.remove('drag');});
$('dropzone').addEventListener('drop',e=>{if(!busy&&e.dataTransfer.files[0])loadPhoto(e.dataTransfer.files[0],e.dataTransfer.files[0].name).catch(()=>error('Could not read file.'));});
function context(){return {crop:$('crop').value,stage:$('stage').value,temp:Number($('temp').value),humidity:Number($('humidity').value),rain:Number($('rain').value)};}
function plan(r,c){
 if(!r.accepted)return {source:'Quality and confidence gate',steps:r.reasons};
 const healthy=r.disease.toLowerCase()==='healthy';
 let steps=healthy?['No disease symptoms were identified by this classifier. Continue checking the crop for changes.']:['Treat this as a possible '+r.disease.toLowerCase()+' finding. Compare symptoms on several leaves and seek confirmation from a local extension officer.','Photograph both sides of a single leaf in natural light and record whether symptoms are spreading.'];
 if(!healthy)steps.push('Treatment selection needs local approval, crop stage and confirmed diagnosis. No pesticide dose is generated from the illustrative prototype rules.');
 if(c.rain>=5)steps.push('You entered rain of '+c.rain+' mm in 24 hours. Discuss weather timing before any label-approved foliar treatment.');
 if(c.stage==='Fruiting')steps.push('The crop is fruiting. Any approved treatment must respect its pre-harvest interval.');
 return {source:'Prototype follow-up rules',steps};
}
function renderResult(){
 if(!result)return;const r=result,c=context(),p=plan(r,c);
 $('status').textContent=r.accepted?'SCREENING COMPLETE':'REVIEW REQUIRED';
 $('result').innerHTML=`<span class="badge ${r.accepted?'':'warn'}">${r.accepted?'POSSIBLE FINDING':'PHOTO / PREDICTION NEEDS REVIEW'}</span><h3 class="result-heading">${r.accepted?esc(r.disease):'A clearer picture, please.'}</h3><p class="subtle">${esc(c.crop)} · ${esc(c.stage)} · ${esc(filename)}</p>
 <div class="score-row"><span class="subtle">${r.accepted?'Top model score':'Top guess (withheld as a diagnosis)'}</span><b>${pct(r.confidence)}</b></div><progress max="1" value="${r.confidence}"></progress><p class="subtle">${r.accepted?'Model score is not a validated probability of correctness.':esc(r.crop+' · '+r.disease)}</p>
 <div class="rule-panel"><p class="small">${esc(p.source.toUpperCase())}</p><h3>${r.accepted?'Your next step':'Before another scan'}</h3><ul>${p.steps.map(s=>`<li>${esc(s)}</li>`).join('')}</ul></div>
 <div class="manual"><span>Severity head: not trained</span><label for="severity">Your estimate %</label><input id="severity" type="number" min="0" max="100" step="1" placeholder="—" value="${severity===null?'':severity}"></div><p class="subtle">Optional manual observation, not model output. Enter the visible leaf area affected.</p>
 <details class="trace"><summary>Inspect the pipeline</summary><div class="trace-line"><span>Model</span><span>${esc(r.model)}</span></div><div class="trace-line"><span>Inference</span><span>${r.elapsed_ms} ms · CPU</span></div><div class="trace-line"><span>Image</span><span>${r.size.join(' × ')} → 224 × 224</span></div><div class="trace-line"><span>Sharpness / minimum</span><span>${r.sharpness} / 35</span></div><div class="trace-line"><span>Training similarity / minimum</span><span>${r.similarity} / ${Number(r.similarity_threshold).toFixed(3)}</span></div><div class="trace-line"><span>Gate / outcome</span><span>${pct(r.gate)} / ${r.accepted?'PASS':'HOLD'}</span></div><p class="small">TOP CANDIDATES · ALL MODEL CLASSES</p>${r.candidates.map(x=>`<div class="candidate"><span>${esc(x.label.replaceAll('___',' · ').replaceAll('_',' '))}</span><span>${pct(x.probability)}</span></div>`).join('')}<p class="subtle">Context bypasses the visual encoder. No cloud inference, trained severity head or grounded LLM is active.</p></details><button id="export" class="button export">Download scan report ↓</button>`;
 $('severity').oninput=e=>{const n=Number(e.target.value);severity=e.target.value!==''&&Number.isFinite(n)&&n>=0&&n<=100?n:null;};
 $('export').onclick=()=>download({...r,context:context(),filename,manual_severity_percent:severity,plan:plan(r,context()),created_at:new Date().toISOString()});
}
function download(value){const url=URL.createObjectURL(new Blob([JSON.stringify(value,null,2)],{type:'application/json'}));const a=document.createElement('a');a.href=url;a.download='agridiagnose-scan.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);}
$('scanForm').onsubmit=async e=>{e.preventDefault();if(!photo||busy||!ready)return;busy=true;controls();const token=revision, image=photo, crop=$('crop').value, gate=Number($('gate').value)/100;$('status').textContent='ANALYSING';$('result').innerHTML='<div class="empty"><div class="spinner"></div><h3>Reading the leaf.</h3><p>The model is running on your computer.</p></div>';
 try {const response=await fetch('/api/diagnose',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({image,crop,gate})});const data=await response.json();if(!response.ok)throw Error(data.error||'Analysis failed.');if(token!==revision)return;result=data;renderResult();history.unshift({result:data,context:context(),filename,created_at:new Date().toISOString()});history=history.slice(0,30);saveHistory();}
 catch(e){if(token===revision){error(e.message);$('status').textContent='SCAN FAILED';}}
 finally{busy=false;controls();}
};
$('crop').onchange=()=>{if(photo)reset();};
$('gate').oninput=()=>{$('gateValue').value=$('gate').value+'%';if(photo)reset();};
for(const id of ['stage','temp','humidity','rain'])$(id).addEventListener('change',renderResult);
function saveHistory(){try{localStorage.setItem('agridiagnose.scans',JSON.stringify(history));}catch{}renderHistory();}
function renderHistory(){$('historyCount').textContent=history.length;$('history').innerHTML=history.length?history.map((h,i)=>`<div class="history-row"><span>${esc(new Date(h.created_at).toLocaleString())}</span><span>${esc(h.context.crop)} · ${esc(h.result.accepted?h.result.disease:'Review required')}</span><button class="text-button" data-index="${i}">Export ↓</button></div>`).join(''):'<p>No scans saved yet.</p>';}
$('history').onclick=e=>{const b=e.target.closest('button');if(b)download(history[Number(b.dataset.index)]);};
$('historyToggle').onclick=()=>{$('historyPanel').hidden=!$('historyPanel').hidden;if(!$('historyPanel').hidden)$('historyPanel').scrollIntoView({behavior:'smooth'});};
$('clearHistory').onclick=()=>{history=[];saveHistory();};renderHistory();
fetch('/api/health').then(r=>{if(!r.ok)throw Error();return r.json();}).then(h=>{ready=h.ready;$('serverState').textContent=(h.custom?'Locally trained head':'Pretrained DINOv2-small')+' · '+h.classes+' classes · CPU · photos stay local';controls();}).catch(()=>{$('serverState').textContent='Local server unavailable. Start the app using Start AgriDiagnose.cmd.';});
