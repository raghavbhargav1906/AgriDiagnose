"""Local-only HTTP server. No cloud services or API keys."""
from inference import Classifier, ROOT
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from urllib.parse import urlparse
import base64, binascii, json, threading

classifier = Classifier()
lock = threading.Lock()
MAX_BODY = 12 * 1024 * 1024

class Handler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(ROOT / 'public'), **kwargs)

    def end_headers(self):
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.send_header('Referrer-Policy', 'no-referrer')
        self.send_header('Content-Security-Policy', "default-src 'self'; img-src 'self' data: blob:; style-src 'self'; script-src 'self'; connect-src 'self'; object-src 'none'; base-uri 'self'; frame-ancestors 'none'")
        super().end_headers()

    def json(self, status, value):
        body = json.dumps(value, allow_nan=False).encode()
        self.send_response(status)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Cache-Control', 'no-store')
        self.send_header('Content-Length', str(len(body)))
        self.end_headers(); self.wfile.write(body)

    def do_GET(self):
        if urlparse(self.path).path == '/api/health':
            return self.json(200, dict(ready=True, local=True, classes=len(classifier.labels), custom=classifier.head is not None))
        super().do_GET()

    def do_POST(self):
        if self.path != '/api/diagnose':
            return self.json(404, {'error':'Unknown endpoint.'})
        # Blocks cross-origin browser requests to this local service.
        origin = self.headers.get('Origin')
        if origin and origin not in ('http://127.0.0.1:8765', 'http://localhost:8765'):
            return self.json(403, {'error':'Cross-origin requests are not allowed.'})
        try:
            length = int(self.headers.get('Content-Length', '0'))
            if not 0 < length <= MAX_BODY:
                return self.json(413, {'error':'Choose an image under 8 MB.'})
            data = json.loads(self.rfile.read(length))
            crop = data.get('crop')
            if crop not in ('Tomato','Potato','Apple','Corn','Grape'):
                raise ValueError('Choose a supported crop.')
            gate = data.get('gate', .65)
            if not isinstance(gate, (float, int)) or not .3 <= gate <= .99:
                raise ValueError('Confidence gate must be between 0.30 and 0.99.')
            encoded = data.get('image', '')
            if not isinstance(encoded, str):
                raise ValueError('Missing image.')
            raw = base64.b64decode(encoded.split(',')[-1], validate=True)
            if not 0 < len(raw) <= 8 * 1024 * 1024:
                raise ValueError('Choose an image under 8 MB.')
            if not lock.acquire(blocking=False):
                return self.json(429, {'error':'Another image is being analysed. Try again shortly.'})
            try:
                result = classifier.predict(raw, crop, gate)
            finally:
                lock.release()
            return self.json(200, result)
        except (ValueError, binascii.Error, OSError, KeyError):
            return self.json(400, {'error':'Could not read this image or request. Use a valid JPEG, PNG or WebP under 8 MB.'})
        except Exception:
            return self.json(500, {'error':'Local inference failed. Check the server console.'})

if __name__ == '__main__':
    server = ThreadingHTTPServer(('127.0.0.1', 8765), Handler)
    print('AgriDiagnose ready: http://127.0.0.1:8765', flush=True)
    import sys
    if '--open' in sys.argv:
        import webbrowser
        webbrowser.open('http://127.0.0.1:8765')
    server.serve_forever()
